"""
Crop Recommendation System
--------------------------
Uses soil nutrients (N, P, K), temperature, humidity, pH, and rainfall
to recommend the most suitable crop using a Random Forest classifier.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import LabelEncoder
import pickle
import os

# ── 1. Generate synthetic dataset ──────────────────────────────────────────────

def generate_dataset(n_samples=2200, seed=42):
    """
    Creates a realistic synthetic dataset for 11 common Indian crops.
    Each crop has a typical range for N, P, K, temperature, humidity, pH, rainfall.
    """
    np.random.seed(seed)

    crops = {
        "rice":        dict(N=(60,80),  P=(40,60),  K=(40,60),  temp=(20,30), hum=(80,90), ph=(5.5,7.0), rain=(150,250)),
        "wheat":       dict(N=(80,120), P=(30,50),  K=(40,60),  temp=(10,25), hum=(30,60), ph=(6.0,7.5), rain=(50,100)),
        "maize":       dict(N=(80,100), P=(40,60),  K=(20,40),  temp=(18,28), hum=(60,70), ph=(5.5,7.5), rain=(60,110)),
        "chickpea":    dict(N=(20,40),  P=(60,80),  K=(60,80),  temp=(15,30), hum=(15,30), ph=(6.0,8.0), rain=(40,80)),
        "kidneybeans": dict(N=(20,40),  P=(60,80),  K=(20,40),  temp=(15,25), hum=(50,70), ph=(6.0,7.5), rain=(100,150)),
        "pigeonpeas":  dict(N=(10,30),  P=(60,80),  K=(20,40),  temp=(18,32), hum=(30,60), ph=(5.5,7.0), rain=(60,120)),
        "mothbeans":   dict(N=(20,40),  P=(40,60),  K=(20,40),  temp=(24,34), hum=(30,60), ph=(3.5,6.5), rain=(30,60)),
        "mungbean":    dict(N=(20,40),  P=(40,60),  K=(20,40),  temp=(25,35), hum=(80,90), ph=(6.2,7.2), rain=(60,100)),
        "blackgram":   dict(N=(30,60),  P=(40,60),  K=(17,40),  temp=(25,35), hum=(65,80), ph=(5.0,7.5), rain=(60,120)),
        "lentil":      dict(N=(10,30),  P=(60,80),  K=(20,40),  temp=(15,25), hum=(60,70), ph=(6.0,7.5), rain=(30,70)),
        "cotton":      dict(N=(100,140),P=(40,60),  K=(20,40),  temp=(24,32), hum=(60,80), ph=(6.0,8.0), rain=(60,110)),
    }

    rows = []
    per_crop = n_samples // len(crops)

    for crop, ranges in crops.items():
        for _ in range(per_crop):
            rows.append({
                "N":           np.random.uniform(*ranges["N"]),
                "P":           np.random.uniform(*ranges["P"]),
                "K":           np.random.uniform(*ranges["K"]),
                "temperature": np.random.uniform(*ranges["temp"]),
                "humidity":    np.random.uniform(*ranges["hum"]),
                "ph":          np.random.uniform(*ranges["ph"]),
                "rainfall":    np.random.uniform(*ranges["rain"]),
                "label":       crop,
            })

    df = pd.DataFrame(rows).sample(frac=1, random_state=seed).reset_index(drop=True)
    return df


# ── 2. Train model ─────────────────────────────────────────────────────────────

def train_model(df):
    """Trains a Random Forest classifier and returns the model + label encoder."""
    le = LabelEncoder()
    X = df[["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]]
    y = le.fit_transform(df["label"])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"\n✅ Model trained successfully!")
    print(f"   Accuracy: {acc * 100:.2f}%\n")
    print("Classification Report:")
    print(classification_report(y_test, y_pred, target_names=le.classes_))

    return model, le, acc


# ── 3. Save & load ─────────────────────────────────────────────────────────────

def save_model(model, le, path="model.pkl"):
    with open(path, "wb") as f:
        pickle.dump({"model": model, "label_encoder": le}, f)
    print(f"💾 Model saved to {path}")


def load_model(path="model.pkl"):
    with open(path, "rb") as f:
        obj = pickle.load(f)
    return obj["model"], obj["label_encoder"]


# ── 4. Predict ─────────────────────────────────────────────────────────────────

def recommend_crop(model, le, N, P, K, temperature, humidity, ph, rainfall):
    """Returns the top-3 recommended crops with confidence scores."""
    features = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
    probs = model.predict_proba(features)[0]
    top3_idx = np.argsort(probs)[::-1][:3]
    results = [
        {"crop": le.classes_[i], "confidence": round(probs[i] * 100, 1)}
        for i in top3_idx
    ]
    return results


# ── 5. Main ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("🌾 Crop Recommendation System")
    print("=" * 40)

    # Generate data
    df = generate_dataset()
    df.to_csv("data/crop_data.csv", index=False)
    print(f"📊 Dataset created: {len(df)} samples, {df['label'].nunique()} crops")

    # Train
    model, le, acc = train_model(df)
    save_model(model, le, "model.pkl")

    # Demo prediction
    print("\n🔍 Sample Prediction:")
    print("   Input → N=90, P=42, K=43, Temp=20°C, Humidity=82%, pH=6.5, Rainfall=200mm")
    results = recommend_crop(model, le, N=90, P=42, K=43,
                             temperature=20, humidity=82, ph=6.5, rainfall=200)
    for i, r in enumerate(results, 1):
        print(f"   #{i}: {r['crop'].capitalize():15s} ({r['confidence']}% confidence)")
