"""
eda.py — Exploratory Data Analysis & Visualizations
Run: python notebooks/eda.py
Saves all charts to reports/figures/
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from model import generate_dataset

os.makedirs("reports/figures", exist_ok=True)

# Generate or load data
DATA_PATH = "data/crop_data.csv"
if os.path.exists(DATA_PATH):
    df = pd.read_csv(DATA_PATH)
else:
    os.makedirs("data", exist_ok=True)
    df = generate_dataset()
    df.to_csv(DATA_PATH, index=False)

print(f"Dataset shape: {df.shape}")
print(df.head())
print("\nCrop distribution:\n", df["label"].value_counts())

FEATURES = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]
COLORS = plt.cm.Set3(np.linspace(0, 1, df["label"].nunique()))
CROP_COLORS = dict(zip(sorted(df["label"].unique()), COLORS))

# ── Plot 1: Crop Distribution ──────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 5))
counts = df["label"].value_counts()
bars = ax.bar(counts.index, counts.values,
              color=[CROP_COLORS[c] for c in counts.index], edgecolor="white", linewidth=1.5)
ax.set_title("Number of Samples per Crop", fontsize=15, fontweight="bold", pad=15)
ax.set_xlabel("Crop", fontsize=12)
ax.set_ylabel("Count", fontsize=12)
ax.tick_params(axis="x", rotation=30)
for bar in bars:
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
            str(int(bar.get_height())), ha="center", va="bottom", fontsize=9)
plt.tight_layout()
plt.savefig("reports/figures/crop_distribution.png", dpi=150)
plt.close()
print("✅ Saved: crop_distribution.png")

# ── Plot 2: Feature Distributions ─────────────────────────────────────────────
fig, axes = plt.subplots(2, 4, figsize=(16, 8))
axes = axes.flatten()
for i, feat in enumerate(FEATURES):
    axes[i].hist(df[feat], bins=30, color="#4CAF50", edgecolor="white", linewidth=0.8)
    axes[i].set_title(feat, fontsize=12, fontweight="bold")
    axes[i].set_xlabel("Value")
    axes[i].set_ylabel("Frequency")
axes[-1].axis("off")
fig.suptitle("Feature Distributions", fontsize=16, fontweight="bold", y=1.01)
plt.tight_layout()
plt.savefig("reports/figures/feature_distributions.png", dpi=150, bbox_inches="tight")
plt.close()
print("✅ Saved: feature_distributions.png")

# ── Plot 3: Avg NPK per Crop ───────────────────────────────────────────────────
avg = df.groupby("label")[["N", "P", "K"]].mean().reset_index()
x = np.arange(len(avg))
width = 0.25
fig, ax = plt.subplots(figsize=(12, 6))
ax.bar(x - width, avg["N"], width, label="N (Nitrogen)", color="#E57373")
ax.bar(x,         avg["P"], width, label="P (Phosphorus)", color="#64B5F6")
ax.bar(x + width, avg["K"], width, label="K (Potassium)", color="#81C784")
ax.set_xticks(x)
ax.set_xticklabels(avg["label"], rotation=30, ha="right")
ax.set_title("Average NPK Values per Crop", fontsize=14, fontweight="bold")
ax.set_ylabel("kg/ha")
ax.legend()
plt.tight_layout()
plt.savefig("reports/figures/npk_per_crop.png", dpi=150)
plt.close()
print("✅ Saved: npk_per_crop.png")

# ── Plot 4: Correlation Heatmap ────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
corr = df[FEATURES].corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="RdYlGn",
            center=0, ax=ax, linewidths=0.5, square=True,
            annot_kws={"size": 10})
ax.set_title("Feature Correlation Heatmap", fontsize=14, fontweight="bold", pad=15)
plt.tight_layout()
plt.savefig("reports/figures/correlation_heatmap.png", dpi=150)
plt.close()
print("✅ Saved: correlation_heatmap.png")

# ── Plot 5: Rainfall & Temperature per Crop ────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
for ax, feat, color in zip(axes, ["rainfall", "temperature"], ["#42A5F5", "#FF7043"]):
    data = [df[df["label"] == c][feat].values for c in sorted(df["label"].unique())]
    bp = ax.boxplot(data, patch_artist=True, notch=False,
                    medianprops=dict(color="black", linewidth=2))
    for patch, col in zip(bp["boxes"], COLORS):
        patch.set_facecolor(col)
    ax.set_xticklabels(sorted(df["label"].unique()), rotation=30, ha="right")
    ax.set_title(f"{feat.capitalize()} by Crop", fontsize=13, fontweight="bold")
    ax.set_ylabel(feat.capitalize())
plt.tight_layout()
plt.savefig("reports/figures/rainfall_temperature_boxplot.png", dpi=150)
plt.close()
print("✅ Saved: rainfall_temperature_boxplot.png")

print("\n🎉 All visualizations saved to reports/figures/")
